package com.auroranime.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
