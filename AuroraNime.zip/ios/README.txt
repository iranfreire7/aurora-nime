Execute `flutter create .` em um projeto Flutter/macOS para gerar o projeto Xcode iOS. Depois use `flutter build ios --release` em um Mac com Xcode.
