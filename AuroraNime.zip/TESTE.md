# Roteiro de teste do Aurora Nime

## Catálogo
1. Abrir o Aurora Nime e conferir a tela inicial.
2. Pesquisar um anime e abrir seus detalhes.
3. Conferir a lista de episódios informativos.

## Primeira etapa Jellyfin (conexão e catálogo)
1. No topo da tela inicial, tocar no ícone de biblioteca para abrir **Minha mídia**.
2. Confirmar o endereço `http://192.168.0.4:8096` (S20 FE) ou editar se o IP do servidor mudou.
3. Informar o usuário e a senha do Jellyfin no próprio aplicativo e tocar em **Conectar ao Jellyfin**.
4. Conferir se as bibliotecas e os episódios são listados.
5. Tocar em uma biblioteca para filtrar os episódios dela.

A senha não é persistida pelo aplicativo; o token de acesso permanece apenas na memória durante a sessão. Esta etapa valida autenticação e listagem. A reprodução dentro do Aurora Nime será integrada em uma etapa posterior.

## Build
O APK deve ser compilado pelo workflow `.github/workflows/android-apk.yml` no GitHub Actions. Este ambiente de edição não possui Flutter SDK para gerar ou validar o APK localmente.

## Teste da reprodução Jellyfin — etapa 2

1. Gerar o APK pelo workflow Android do GitHub Actions.
2. Instalar no Android/TV conectado à mesma rede do servidor Jellyfin.
3. Abrir **Minha mídia**, informar servidor, usuário e senha Jellyfin.
4. Confirmar que as bibliotecas e o episódio aparecem.
5. Selecionar o episódio e validar imagem, áudio, pausa, avanço/retrocesso e botão voltar.
6. Repetir a navegação usando o controle remoto da TV (setas, OK/Enter e voltar).
7. Se o vídeo não abrir, registrar o texto do erro e o formato do arquivo para avaliar compatibilidade/transcodificação.
