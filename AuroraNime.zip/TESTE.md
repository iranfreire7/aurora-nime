# Fase de teste — Aurora Nime

## Prévia rápida no celular
Abra o arquivo `Aurora_Nime_Teste.html` em um navegador. Deixe `Aurora_Nime_Capa.png` na mesma pasta para mostrar o ícone escolhido. Esta prévia permite testar navegação, filtros e favoritos; não é um APK.

## Teste do aplicativo Flutter
É necessário instalar Flutter SDK e Android Studio:
1. Extraia o ZIP do projeto.
2. Abra a pasta no Android Studio (ou terminal).
3. Execute `flutter pub get`.
4. Conecte um Android e execute `flutter run`, ou gere o APK com `flutter build apk --debug`.
5. Para TV, teste foco e navegação com o controle direcional em Android TV/TV Stick/TV Box compatível.
6. Para iOS, é necessário Mac com Xcode; execute `flutter run` em simulador ou iPhone autorizado.

## Limites atuais
Este é um protótipo visual. A lista de episódios consulta o catálogo público Tenrai quando há dados disponíveis. Não há reprodução de vídeo, catálogo licenciado, capas oficiais verificadas nem atualização automática de lançamentos. A disponibilidade de dublagem deve ser verificada por fonte licenciada.
