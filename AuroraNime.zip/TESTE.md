# Conferência da revisão segura — Aurora Nime

## Antes de instalar
Esta pasta contém o código-fonte Flutter. O ZIP ainda precisa passar pela compilação do GitHub Actions e por testes em um aparelho Android. Não é um APK pronto.

## Pontos desta revisão
- Mantém a interface, os assets e a estrutura do projeto que vieram da base `correcao_completa`.
- Mantém a identificação por títulos alternativos e a pontuação de correspondência.
- Usa ano e tipo, quando disponíveis, para desempatar temporadas; quando houver empate, usa ano e tipo se disponíveis; sem esses dados, preserva o primeiro resultado da API, que vem ordenado por relevância.
- A consulta Jikan só é marcada como concluída quando a paginação termina normalmente. HTTP 429, falhas de rede e respostas incompletas permitem nova tentativa.
- Exibe uma ação para tentar buscar episódios restantes quando a fonte secundária ainda não concluiu a consulta.
- Mantém os episódios já carregados, remove duplicações por número e ordena numericamente.

## Validação obrigatória no GitHub Actions
1. Envie o conteúdo deste ZIP para o repositório somente quando estiver pronto para testar uma nova compilação.
2. Execute o workflow `Gerar APK Aurora Nime`.
3. Se a compilação falhar, não instale nem substitua o APK atual.
4. Se a compilação passar, instale o APK de teste e confira pesquisa, capas, detalhes, Demon Slayer e Overgeared.
5. Em Overgeared, confira se a consulta secundária consegue encontrar o episódio 9 quando a fonte principal informar um total maior que a lista carregada.
6. Em Demon Slayer, confira se a tela de episódios identifica a obra correta. Se houver ambiguidade, o app deve evitar escolher uma temporada arbitrariamente.

## Limitações conhecidas
- Esta revisão não implementa tradução automática dos títulos e sinopses para português. O idioma depende dos dados fornecidos pelas fontes.
- A consulta Jikan depende da disponibilidade e dos limites de requisição do serviço.
- A revisão do código e a integridade do ZIP não substituem compilação e teste em aparelho real.
