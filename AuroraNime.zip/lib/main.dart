import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

void main() => runApp(const AuroraNimeApp());

const bg = Color(0xFF0B0914);
const panel = Color(0xFF1B1728);
const purple = Color(0xFF9B59E8);

class AuroraNimeApp extends StatelessWidget {
  const AuroraNimeApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Aurora Nime',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: bg,
        colorScheme: ColorScheme.fromSeed(seedColor: purple, brightness: Brightness.dark),
        useMaterial3: true,
        cardColor: panel,
      ),
      home: const HomePage(),
    );
  }
}

class Anime {
  final String title, genre, synopsis, emoji;
  final bool dubbed, recent;
  final String? posterUrl, status, type;
  final double? score;
  final int? year, episodes;
  const Anime(this.title, this.genre, this.synopsis, this.emoji,
      {this.dubbed = true, this.recent = false, this.posterUrl,
      this.status, this.type, this.score, this.year, this.episodes});
}

const animes = <Anime>[
  Anime('Naruto', 'Ação • Aventura', 'A jornada de Naruto Uzumaki para se tornar Hokage.', '🍥'),
  Anime('One Piece', 'Aventura', 'Luffy e sua tripulação partem em busca do lendário tesouro.', '🏴‍☠️'),
  Anime('Dragon Ball', 'Ação', 'Goku e seus amigos protegem a Terra de grandes ameaças.', '🐉'),
  Anime('Demon Slayer', 'Fantasia', 'Tanjiro enfrenta demônios para proteger sua família.', '⚔️', recent: true),
  Anime('Jujutsu Kaisen', 'Sobrenatural', 'Jovens feiticeiros enfrentam maldições perigosas.', '👊', recent: true),
  Anime('Solo Leveling', 'Fantasia', 'Um caçador considerado fraco recebe um poder misterioso.', '🌑', recent: true),
  Anime('My Hero Academia', 'Ação', 'Um jovem sonha em se tornar o maior herói.', '🦸'),
  Anime('Spy x Family', 'Comédia', 'Uma família improvável esconde segredos divertidos.', '🕵️'),
];

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int tab = 0;
  String query = '';
  String selectedGenre = 'Todos';
  final Set<String> favorites = {};
  final FocusNode searchFocus = FocusNode();
  Timer? _searchDebounce;
  int _searchRequestId = 0;
  bool _searchLoading = false;
  String? _searchError;
  List<Anime> _searchResults = [];

  String get heading => query.trim().isNotEmpty ? 'Resultados da pesquisa' : ['Animes populares', 'Animes dublados', 'Lançamentos recentes', 'Meus favoritos', 'Buscar animes'][tab];

  List<Anime> get visible {
    final source = query.trim().isNotEmpty ? _searchResults : animes;
    return source.where((a) {
      final matchesTab = query.trim().isNotEmpty ? true : switch (tab) {
        1 => a.dubbed,
        2 => a.recent,
        3 => favorites.contains(a.title),
        _ => true,
      };
      final matchesGenre = selectedGenre == 'Todos' || a.genre.toLowerCase().contains(selectedGenre.toLowerCase());
      return matchesTab && matchesGenre && a.title.toLowerCase().contains(query.toLowerCase());
    }).toList();
  }

  void selectTab(int index) {
    setState(() {
      tab = index;
      query = '';
      _searchDebounce?.cancel();
      _searchRequestId++;
      _searchResults = [];
      _searchError = null;
      _searchLoading = false;
      selectedGenre = 'Todos';
    });
    if (index == 4) {
      WidgetsBinding.instance.addPostFrameCallback((_) => searchFocus.requestFocus());
    }
  }

  void _onSearchChanged(String value) {
    _searchRequestId++; // invalida qualquer resposta de uma pesquisa anterior
    setState(() {
      query = value;
      _searchError = null;
      _searchResults = [];
    });
    _searchDebounce?.cancel();
    final term = value.trim();
    if (term.length < 2) {
      setState(() => _searchLoading = false);
      return;
    }
    setState(() => _searchLoading = true);
    _searchDebounce = Timer(const Duration(milliseconds: 550), () {
      _searchOnline(term);
    });
  }

  Future<void> _searchOnline(String term) async {
    final requestId = ++_searchRequestId;
    try {
      final uri = Uri.https('api.tenrai.org', '/v1/anime', {'q': term});
      final response = await http.get(uri, headers: const {
        'Accept': 'application/json',
        'User-Agent': 'AuroraNime/1.0',
      }).timeout(const Duration(seconds: 20));
      if (requestId != _searchRequestId || !mounted) return;
      if (response.statusCode != 200) {
        setState(() {
          _searchLoading = false;
          _searchError = 'Não foi possível pesquisar agora (HTTP ${response.statusCode}). Tente novamente.';
        });
        return;
      }
      final decoded = jsonDecode(response.body);
      final rawData = decoded is Map ? decoded['data'] : null;
      if (rawData is! List) {
        setState(() {
          _searchLoading = false;
          _searchError = 'A resposta do catálogo veio em um formato inesperado.';
        });
        return;
      }
      final results = <Anime>[];
      final seen = <String>{};
      for (final item in rawData) {
        if (item is! Map) continue;
        final englishTitle = item['title_english']?.toString().trim() ?? '';
        final title = englishTitle.isNotEmpty ? englishTitle : (item['title']?.toString().trim() ?? '');
        if (title.isEmpty || !seen.add(title.toLowerCase())) continue;
        final genreData = item['genres'];
        final genres = genreData is List
            ? genreData.map((g) => g is Map ? (g['name'] ?? '').toString() : '').where((g) => g.isNotEmpty).take(3).join(' • ')
            : '';
        final images = item['images'];
        String? poster;
        if (images is Map) {
          final webp = images['webp'];
          final jpg = images['jpg'];
          for (final candidate in [
            if (webp is Map) webp['large_image_url'],
            if (jpg is Map) jpg['large_image_url'],
            if (webp is Map) webp['image_url'],
            if (jpg is Map) jpg['image_url'],
          ]) {
            if (candidate is String && candidate.startsWith('https://')) { poster = candidate; break; }
          }
        }
        results.add(Anime(
          title,
          genres.isEmpty ? 'Anime' : genres,
          (item['synopsis'] ?? 'Informações não disponíveis no momento.').toString(),
          '🎬',
          posterUrl: poster,
          score: (item['score'] is num) ? (item['score'] as num).toDouble() : null,
          year: (item['year'] is num) ? (item['year'] as num).toInt() :
              ((item['aired'] is Map && item['aired']['prop'] is Map && item['aired']['prop']['from'] is Map)
                  ? (item['aired']['prop']['from']['year'] as num?)?.toInt() : null),
          episodes: item['episodes'] is num ? (item['episodes'] as num).toInt() : null,
          status: item['status']?.toString(),
          type: item['type']?.toString(),
        ));
      }
      if (!mounted || requestId != _searchRequestId) return;
      setState(() {
        _searchResults = results;
        _searchLoading = false;
        _searchError = null;
      });
    } on TimeoutException {
      if (!mounted || requestId != _searchRequestId) return;
      setState(() { _searchLoading = false; _searchError = 'A pesquisa demorou demais. Verifique a internet e tente novamente.'; });
    } catch (_) {
      if (!mounted || requestId != _searchRequestId) return;
      setState(() { _searchLoading = false; _searchError = 'Não foi possível consultar o catálogo. Tente novamente.'; });
    }
  }

  @override
  void dispose() {
    _searchDebounce?.cancel();
    _searchRequestId++;
    searchFocus.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final wide = MediaQuery.sizeOf(context).width >= 650;
    return Scaffold(
      body: SafeArea(
        child: LayoutBuilder(builder: (context, constraints) {
          final columns = constraints.maxWidth >= 1050 ? 5 : constraints.maxWidth >= 650 ? 4 : 2;
          return CustomScrollView(
            slivers: [
              SliverPadding(
                padding: EdgeInsets.symmetric(horizontal: wide ? 28 : 16, vertical: 14),
                sliver: SliverList.list(children: [
                  Row(children: [
                    const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text('AURORA NIME', style: TextStyle(fontSize: 25, fontWeight: FontWeight.w900, letterSpacing: -1, color: Color(0xFFD2A0FF))),
                      Text('SEU MUNDO DE ANIMES!', style: TextStyle(fontSize: 10, color: Colors.white60, letterSpacing: 1.2)),
                    ])),
                    ClipRRect(
                      borderRadius: BorderRadius.circular(13),
                      child: Image.asset('assets/images/aurora_nime_capa.png', width: 52, height: 52, fit: BoxFit.cover),
                    ),
                  ]),
                  const SizedBox(height: 14),
                  if (wide) ...[
                    Wrap(
                      crossAxisAlignment: WrapCrossAlignment.center,
                      spacing: 8,
                      runSpacing: 8,
                      children: [
                        _topNavButton('⌂ Início', 0),
                        _topNavButton('🎙 Dublados', 1),
                        _topNavButton('✨ Recentes', 2),
                        _topNavButton('♥ Favoritos', 3),
                        SizedBox(
                          width: constraints.maxWidth >= 900 ? 300 : 220,
                          child: TextField(
                            focusNode: searchFocus,
                            onChanged: _onSearchChanged,
                            decoration: InputDecoration(
                              hintText: 'Buscar anime...',
                              prefixIcon: const Icon(Icons.search),
                              isDense: true,
                              filled: true,
                              fillColor: panel,
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(12),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 16),
                  ],
                  Container(
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(18),
                      gradient: const LinearGradient(colors: [Color(0xFF48206F), Color(0xFF17142C)]),
                      border: Border.all(color: const Color(0xFF65418B)),
                    ),
                    child: Row(children: [
                      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        const Text('BEM-VINDO AO SEU UNIVERSO', style: TextStyle(fontSize: 10, color: Color(0xFFE0C8FF), letterSpacing: 1)),
                        const SizedBox(height: 8),
                        Text('Sua próxima aventura começa aqui!', style: TextStyle(fontSize: wide ? 25 : 20, fontWeight: FontWeight.w900)),
                        const SizedBox(height: 6),
                        const Text('Animes, favoritos e novidades em um só lugar.', style: TextStyle(fontSize: 12, color: Colors.white70)),
                        const SizedBox(height: 12),
                        FilledButton(onPressed: () => selectTab(0), child: const Text('Explorar animes')),
                      ])),
                      if (wide) const Text('🌸', style: TextStyle(fontSize: 62)),
                    ]),
                  ),
                  const SizedBox(height: 14),
                  if (!wide)
                    SingleChildScrollView(
                      scrollDirection: Axis.horizontal,
                      child: Row(children: List.generate(5, (i) {
                        const labels = ['⌂ Início', '🎙 Dublados', '✨ Recentes', '♥ Favoritos', '⌕ Buscar'];
                        return Padding(
                          padding: const EdgeInsets.only(right: 8),
                          child: ChoiceChip(
                            label: Text(labels[i]),
                            selected: tab == i,
                            onSelected: (_) => selectTab(i),
                          ),
                        );
                      })),
                    ),
                  if (!wide && tab == 4) ...[
                    const SizedBox(height: 8),
                    TextField(
                      focusNode: searchFocus,
                      onChanged: _onSearchChanged,
                      decoration: InputDecoration(
                        hintText: 'Buscar anime pelo nome...',
                        prefixIcon: const Icon(Icons.search),
                        filled: true, fillColor: panel,
                        border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                      ),
                    ),
                  ],
                  const SizedBox(height: 18),
                  Row(children: [
                    Expanded(child: Text(heading, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w800))),
                    Text('${visible.length} títulos', style: const TextStyle(color: Colors.white54, fontSize: 11)),
                  ]),
                  const SizedBox(height: 10),
                  SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: Row(children: [
                      for (final genre in const ['Todos', 'Ação', 'Aventura', 'Fantasia', 'Sobrenatural', 'Comédia'])
                        Padding(
                          padding: const EdgeInsets.only(right: 8),
                          child: ChoiceChip(
                            label: Text(genre),
                            selected: selectedGenre == genre,
                            onSelected: (_) => setState(() => selectedGenre = genre),
                          ),
                        ),
                    ]),
                  ),
                  const SizedBox(height: 10),
                ]),
              ),
              if (_searchLoading)
                const SliverToBoxAdapter(child: Padding(
                  padding: EdgeInsets.all(28),
                  child: Center(child: CircularProgressIndicator()),
                ))
              else if (_searchError != null)
                SliverToBoxAdapter(child: Center(child: Padding(
                  padding: const EdgeInsets.all(24),
                  child: Text(_searchError!, textAlign: TextAlign.center),
                )))
              else if (query.trim().length == 1)
                const SliverToBoxAdapter(child: Center(child: Padding(
                  padding: EdgeInsets.all(24), child: Text('Digite pelo menos 2 letras para pesquisar.'),
                )))
              else if (visible.isEmpty)
                SliverToBoxAdapter(child: Center(child: Padding(
                  padding: const EdgeInsets.all(30), child: Text(query.trim().isEmpty ? 'Nenhum anime nesta seção.' : 'Nenhum anime encontrado para "$query".'),
                )))
              else
                SliverPadding(
                  padding: EdgeInsets.symmetric(horizontal: wide ? 28 : 16),
                  sliver: SliverGrid(
                    delegate: SliverChildBuilderDelegate((context, index) {
                      final anime = visible[index];
                      return AnimeCard(anime: anime, onTap: () => showAnime(anime));
                    }, childCount: visible.length),
                    gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: columns,
                      crossAxisSpacing: 12,
                      mainAxisSpacing: 12,
                      childAspectRatio: wide ? 0.88 : 0.82,
                    ),
                  ),
                ),
              SliverToBoxAdapter(child: Padding(
                padding: const EdgeInsets.all(18),
                child: Text(
                  'Versão demonstrativa. As capas são carregadas pela internet e pertencem aos respectivos titulares. A disponibilidade de dublagem e lançamentos pode variar. Não há reprodução de episódios nesta versão.',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: Colors.white.withOpacity(.48), fontSize: 11),
                ),
              )),
            ],
          );
        }),
      ),
    );
  }

  Widget _topNavButton(String label, int index) {
    return ChoiceChip(
      label: Text(label),
      selected: tab == index,
      onSelected: (_) => selectTab(index),
    );
  }

  void showAnime(Anime anime) {
    showDialog(context: context, builder: (dialogContext) => AlertDialog(
      backgroundColor: panel,
      scrollable: true,
      title: Text('${anime.emoji}  ${anime.title}'),
      content: SizedBox(
        width: 440,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            if (anime.posterUrl != null)
              Center(
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(12),
                  child: Image.network(
                    anime.posterUrl!, height: 210, width: 150, fit: BoxFit.cover,
                    errorBuilder: (_, __, ___) => const SizedBox.shrink(),
                  ),
                ),
              ),
            if (anime.posterUrl != null) const SizedBox(height: 14),
            Text(anime.genre, style: const TextStyle(color: Color(0xFFD2A0FF), fontWeight: FontWeight.w600)),
            const SizedBox(height: 12),
            const Text('SINOPSE', style: TextStyle(fontWeight: FontWeight.bold, letterSpacing: 1)),
            const SizedBox(height: 5),
            Text(anime.synopsis),
            const SizedBox(height: 14),
            Wrap(spacing: 8, runSpacing: 8, children: [
              if (anime.score != null) _detailChip('★ ${anime.score!.toStringAsFixed(1)}'),
              if (anime.year != null) _detailChip('Ano: ${anime.year}'),
              if (anime.episodes != null) _detailChip('Episódios: ${anime.episodes}'),
              if (anime.type != null && anime.type!.isNotEmpty) _detailChip(anime.type!),
              if (anime.status != null && anime.status!.isNotEmpty) _detailChip(anime.status!),
            ]),
            const SizedBox(height: 14),
            Text('As informações dependem dos dados disponíveis no catálogo. A reprodução de episódios ainda não está integrada nesta versão.',
              style: TextStyle(color: Colors.white.withOpacity(.58), fontSize: 11)),
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: () {
            setState(() {
              if (favorites.contains(anime.title)) {
                favorites.remove(anime.title);
              } else {
                favorites.add(anime.title);
              }
            });
            Navigator.pop(dialogContext);
          },
          child: Text(favorites.contains(anime.title) ? 'Remover favorito' : 'Adicionar aos favoritos'),
        ),
        FilledButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('Fechar')),
      ],
    ));
  }

  Widget _detailChip(String label) => Chip(
    label: Text(label, style: const TextStyle(fontSize: 11)),
    backgroundColor: const Color(0xFF302340),
    side: BorderSide.none,
    visualDensity: VisualDensity.compact,
  );
}


class AnimePosterService {
  static final Map<String, Future<String?>> _cache = {};
  static Future<void> _queue = Future<void>.value();

  static String _normalize(String value) =>
      value.toLowerCase().replaceAll(RegExp(r'[^a-z0-9]'), '');

  static Future<String?> poster(String title) {
    return _cache.putIfAbsent(title, () {
      final result = Completer<String?>();
      _queue = _queue.then((_) async {
        // A API pública permite até 4 requisições por segundo.
        // O intervalo de 600 ms mantém o aplicativo abaixo desse limite.
        await Future<void>.delayed(const Duration(milliseconds: 600));
        try {
          final uri = Uri.https('api.tenrai.org', '/v1/anime', {
            'q': title,
            'sfw': 'true',
          });

          for (var attempt = 0; attempt < 2; attempt++) {
            try {
              final response = await http.get(uri, headers: const {
                'Accept': 'application/json',
                'User-Agent': 'AuroraNime/1.0',
              }).timeout(const Duration(seconds: 18));

              if ((response.statusCode == 429 || response.statusCode >= 500) &&
                  attempt == 0) {
                await Future<void>.delayed(const Duration(seconds: 2));
                continue;
              }
              if (response.statusCode != 200) break;

              final decoded = jsonDecode(response.body);
              if (decoded is! Map<String, dynamic>) break;
              final data = decoded['data'];
              if (data is! List) break;

              final entries = data.whereType<Map<String, dynamic>>().toList();
              if (entries.isEmpty) break;

              // Prefere correspondência exata para evitar capa de anime homônimo.
              Map<String, dynamic>? selected;
              final wanted = _normalize(title);
              for (final entry in entries) {
                final names = [entry['title'], entry['title_english'],
                  entry['title_japanese']];
                if (names.any((name) => name is String &&
                    _normalize(name) == wanted)) {
                  selected = entry;
                  break;
                }
              }
              selected ??= entries.first;

              final images = selected['images'];
              if (images is! Map<String, dynamic>) break;
              final webp = images['webp'];
              final jpg = images['jpg'];
              final webpMap = webp is Map<String, dynamic> ? webp : null;
              final jpgMap = jpg is Map<String, dynamic> ? jpg : null;
              final candidates = [
                webpMap?['large_image_url'],
                jpgMap?['large_image_url'],
                webpMap?['image_url'],
                jpgMap?['image_url'],
              ];
              for (final candidate in candidates) {
                if (candidate is String && candidate.isNotEmpty) {
                  final parsed = Uri.tryParse(candidate);
                  if (parsed != null &&
                      (parsed.scheme == 'https' || parsed.scheme == 'http') &&
                      parsed.host.isNotEmpty) {
                    result.complete(candidate);
                    return;
                  }
                }
              }
              break;
            } catch (_) {
              if (attempt == 0) {
                await Future<void>.delayed(const Duration(seconds: 2));
                continue;
              }
            }
          }
          if (!result.isCompleted) result.complete(null);
        } catch (_) {
          if (!result.isCompleted) result.complete(null);
        }
      }).catchError((_) {
        if (!result.isCompleted) result.complete(null);
      });
      return result.future;
    });
  }
}

class AnimeCard extends StatelessWidget {
  final Anime anime;
  final VoidCallback onTap;
  const AnimeCard({super.key, required this.anime, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Card(
      clipBehavior: Clip.antiAlias,
      color: panel,
      child: InkWell(
        onTap: onTap,
        focusColor: const Color(0xFF533078),
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Expanded(
            child: FutureBuilder<String?>(
              future: anime.posterUrl != null
                  ? Future<String?>.value(anime.posterUrl)
                  : AnimePosterService.poster(anime.title),
              builder: (context, snapshot) {
                final imageUrl = snapshot.data;
                if (imageUrl == null || imageUrl.isEmpty) {
                  return Container(
                    alignment: Alignment.center,
                    decoration: const BoxDecoration(
                      gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Color(0xFF48266D), Color(0xFF172B4C)]),
                    ),
                    child: snapshot.connectionState == ConnectionState.waiting
                        ? const CircularProgressIndicator(strokeWidth: 2)
                        : Text(anime.emoji, style: const TextStyle(fontSize: 48)),
                  );
                }
                return Image.network(
                  imageUrl,
                  fit: BoxFit.cover,
                  width: double.infinity,
                  errorBuilder: (context, error, stackTrace) => Container(
                    alignment: Alignment.center,
                    color: const Color(0xFF241B35),
                    child: Text(anime.emoji, style: const TextStyle(fontSize: 48)),
                  ),
                );
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(9),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(anime.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.bold)),
              const SizedBox(height: 3),
              Text('${anime.genre} • ${anime.dubbed ? 'Dublado*' : 'Sem informação'}', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 10, color: Colors.white60)),
            ]),
          ),
        ]),
      ),
    );
  }
}
