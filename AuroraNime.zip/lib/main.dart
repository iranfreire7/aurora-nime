import 'package:flutter/material.dart';

void main() => runApp(const AuroraNimeApp());

const bg = Color(0xFF0B0914);
const panel = Color(0xFF1B1728);
const purple = Color(0xFF9B59E8);

class AuroraNimeApp extends StatelessWidget {
  const AuroraNimeApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Aurora Nime',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: bg,
        colorScheme: ColorScheme.fromSeed(seedColor: purple, brightness: Brightness.dark),
        useMaterial3: true,
        cardColor: panel,
      ),
      home: const HomePage(),
    );
  }
}

class Anime {
  final String title, genre, synopsis, emoji;
  final bool dubbed, recent;
  const Anime(this.title, this.genre, this.synopsis, this.emoji,
      {this.dubbed = true, this.recent = false});
}

const animes = <Anime>[
  Anime('Naruto', 'Ação • Aventura', 'A jornada de Naruto Uzumaki para se tornar Hokage.', '🍥'),
  Anime('One Piece', 'Aventura', 'Luffy e sua tripulação partem em busca do lendário tesouro.', '🏴‍☠️'),
  Anime('Dragon Ball', 'Ação', 'Goku e seus amigos protegem a Terra de grandes ameaças.', '🐉'),
  Anime('Demon Slayer', 'Fantasia', 'Tanjiro enfrenta demônios para proteger sua família.', '⚔️', recent: true),
  Anime('Jujutsu Kaisen', 'Sobrenatural', 'Jovens feiticeiros enfrentam maldições perigosas.', '👊', recent: true),
  Anime('Solo Leveling', 'Fantasia', 'Um caçador considerado fraco recebe um poder misterioso.', '🌑', recent: true),
  Anime('My Hero Academia', 'Ação', 'Um jovem sonha em se tornar o maior herói.', '🦸'),
  Anime('Spy x Family', 'Comédia', 'Uma família improvável esconde segredos divertidos.', '🕵️'),
];

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int tab = 0;
  String query = '';
  final Set<String> favorites = {};
  final FocusNode searchFocus = FocusNode();

  String get heading => ['Animes populares', 'Animes dublados', 'Lançamentos recentes', 'Meus favoritos', 'Buscar animes'][tab];

  List<Anime> get visible {
    return animes.where((a) {
      final matchesTab = switch (tab) {
        1 => a.dubbed,
        2 => a.recent,
        3 => favorites.contains(a.title),
        _ => true,
      };
      return matchesTab && a.title.toLowerCase().contains(query.toLowerCase());
    }).toList();
  }

  void selectTab(int index) {
    setState(() {
      tab = index;
      query = '';
    });
    if (index == 4) {
      WidgetsBinding.instance.addPostFrameCallback((_) => searchFocus.requestFocus());
    }
  }

  @override
  void dispose() {
    searchFocus.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final wide = MediaQuery.sizeOf(context).width >= 650;
    return Scaffold(
      body: SafeArea(
        child: LayoutBuilder(builder: (context, constraints) {
          final columns = constraints.maxWidth >= 1050 ? 5 : constraints.maxWidth >= 650 ? 4 : 2;
          return CustomScrollView(
            slivers: [
              SliverPadding(
                padding: EdgeInsets.symmetric(horizontal: wide ? 28 : 16, vertical: 14),
                sliver: SliverList.list(children: [
                  Row(children: [
                    const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text('AURORA NIME', style: TextStyle(fontSize: 25, fontWeight: FontWeight.w900, letterSpacing: -1, color: Color(0xFFD2A0FF))),
                      Text('SEU MUNDO DE ANIMES!', style: TextStyle(fontSize: 10, color: Colors.white60, letterSpacing: 1.2)),
                    ])),
                    ClipRRect(
                      borderRadius: BorderRadius.circular(13),
                      child: Image.asset('assets/images/aurora_nime_capa.png', width: 52, height: 52, fit: BoxFit.cover),
                    ),
                  ]),
                  const SizedBox(height: 14),
                  if (wide) ...[
                    Wrap(
                      crossAxisAlignment: WrapCrossAlignment.center,
                      spacing: 8,
                      runSpacing: 8,
                      children: [
                        _topNavButton('⌂ Início', 0),
                        _topNavButton('🎙 Dublados', 1),
                        _topNavButton('✨ Recentes', 2),
                        _topNavButton('♥ Favoritos', 3),
                        SizedBox(
                          width: constraints.maxWidth >= 900 ? 300 : 220,
                          child: TextField(
                            focusNode: searchFocus,
                            onChanged: (v) => setState(() => query = v),
                            decoration: InputDecoration(
                              hintText: 'Buscar anime...',
                              prefixIcon: const Icon(Icons.search),
                              isDense: true,
                              filled: true,
                              fillColor: panel,
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(12),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 16),
                  ],
                  Container(
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(18),
                      gradient: const LinearGradient(colors: [Color(0xFF48206F), Color(0xFF17142C)]),
                      border: Border.all(color: const Color(0xFF65418B)),
                    ),
                    child: Row(children: [
                      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        const Text('BEM-VINDO AO SEU UNIVERSO', style: TextStyle(fontSize: 10, color: Color(0xFFE0C8FF), letterSpacing: 1)),
                        const SizedBox(height: 8),
                        Text('Sua próxima aventura começa aqui!', style: TextStyle(fontSize: wide ? 25 : 20, fontWeight: FontWeight.w900)),
                        const SizedBox(height: 6),
                        const Text('Animes, favoritos e novidades em um só lugar.', style: TextStyle(fontSize: 12, color: Colors.white70)),
                        const SizedBox(height: 12),
                        FilledButton(onPressed: () => selectTab(0), child: const Text('Explorar animes')),
                      ])),
                      if (wide) const Text('🌸', style: TextStyle(fontSize: 62)),
                    ]),
                  ),
                  const SizedBox(height: 14),
                  if (!wide)
                    SingleChildScrollView(
                      scrollDirection: Axis.horizontal,
                      child: Row(children: List.generate(5, (i) {
                        const labels = ['⌂ Início', '🎙 Dublados', '✨ Recentes', '♥ Favoritos', '⌕ Buscar'];
                        return Padding(
                          padding: const EdgeInsets.only(right: 8),
                          child: ChoiceChip(
                            label: Text(labels[i]),
                            selected: tab == i,
                            onSelected: (_) => selectTab(i),
                          ),
                        );
                      })),
                    ),
                  if (!wide && tab == 4) ...[
                    const SizedBox(height: 8),
                    TextField(
                      focusNode: searchFocus,
                      onChanged: (v) => setState(() => query = v),
                      decoration: InputDecoration(
                        hintText: 'Buscar anime pelo nome...',
                        prefixIcon: const Icon(Icons.search),
                        filled: true, fillColor: panel,
                        border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                      ),
                    ),
                  ],
                  const SizedBox(height: 18),
                  Row(children: [
                    Expanded(child: Text(heading, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w800))),
                    Text('${visible.length} títulos', style: const TextStyle(color: Colors.white54, fontSize: 11)),
                  ]),
                  const SizedBox(height: 10),
                ]),
              ),
              if (visible.isEmpty)
                const SliverToBoxAdapter(child: Center(child: Padding(
                  padding: EdgeInsets.all(30), child: Text('Nenhum anime encontrado.'),
                )))
              else
                SliverPadding(
                  padding: EdgeInsets.symmetric(horizontal: wide ? 28 : 16),
                  sliver: SliverGrid(
                    delegate: SliverChildBuilderDelegate((context, index) {
                      final anime = visible[index];
                      return AnimeCard(anime: anime, onTap: () => showAnime(anime));
                    }, childCount: visible.length),
                    gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: columns,
                      crossAxisSpacing: 12,
                      mainAxisSpacing: 12,
                      childAspectRatio: wide ? 0.88 : 0.82,
                    ),
                  ),
                ),
              SliverToBoxAdapter(child: Padding(
                padding: const EdgeInsets.all(18),
                child: Text(
                  'Versão inicial demonstrativa. Capas, disponibilidade de dublagem e lançamentos precisam ser ligados a um catálogo licenciado. Não há reprodução de episódios nesta versão.',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: Colors.white.withOpacity(.48), fontSize: 11),
                ),
              )),
            ],
          );
        }),
      ),
    );
  }

  Widget _topNavButton(String label, int index) {
    return ChoiceChip(
      label: Text(label),
      selected: tab == index,
      onSelected: (_) => selectTab(index),
    );
  }

  void showAnime(Anime anime) {
    showDialog(context: context, builder: (context) => AlertDialog(
      backgroundColor: panel,
      title: Text('${anime.emoji}  ${anime.title}'),
      content: Text('${anime.genre}\n\n${anime.synopsis}\n\nCatálogo demonstrativo: a reprodução e a disponibilidade de episódios ainda não estão integradas.'),
      actions: [
        TextButton(
          onPressed: () {
            setState(() {
              if (favorites.contains(anime.title)) {
                favorites.remove(anime.title);
              } else {
                favorites.add(anime.title);
              }
            });
            Navigator.pop(context);
          },
          child: Text(favorites.contains(anime.title) ? 'Remover favorito' : 'Adicionar aos favoritos'),
        ),
        FilledButton(onPressed: () => Navigator.pop(context), child: const Text('Fechar')),
      ],
    ));
  }
}

class AnimeCard extends StatelessWidget {
  final Anime anime;
  final VoidCallback onTap;
  const AnimeCard({super.key, required this.anime, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Card(
      clipBehavior: Clip.antiAlias,
      color: panel,
      child: InkWell(
        onTap: onTap,
        focusColor: const Color(0xFF533078),
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Expanded(
            child: Container(
              alignment: Alignment.center,
              decoration: const BoxDecoration(
                gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Color(0xFF48266D), Color(0xFF172B4C)]),
              ),
              child: Text(anime.emoji, style: const TextStyle(fontSize: 48)),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(9),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(anime.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.bold)),
              const SizedBox(height: 3),
              Text('${anime.genre} • ${anime.dubbed ? 'Dublado*' : 'Sem informação'}', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 10, color: Colors.white60)),
            ]),
          ),
        ]),
      ),
    );
  }
}
