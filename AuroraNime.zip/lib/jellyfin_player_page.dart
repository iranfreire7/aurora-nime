import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:video_player/video_player.dart';

class JellyfinPlayerPage extends StatefulWidget {
  final String serverUrl;
  final String accessToken;
  final Map<String, dynamic> episode;

  const JellyfinPlayerPage({
    super.key,
    required this.serverUrl,
    required this.accessToken,
    required this.episode,
  });

  @override
  State<JellyfinPlayerPage> createState() => _JellyfinPlayerPageState();
}

class _JellyfinPlayerPageState extends State<JellyfinPlayerPage> {
  VideoPlayerController? _controller;
  String? _error;
  bool _loading = true;
  bool _showControls = true;

  String get _title => widget.episode['Name']?.toString() ?? 'Reproduzindo';

  @override
  void initState() {
    super.initState();
    _initializePlayer();
  }

  Future<void> _initializePlayer() async {
    await _controller?.dispose();
    _controller = null;
    final itemId = widget.episode['Id']?.toString();
    if (itemId == null || itemId.isEmpty) {
      setState(() {
        _loading = false;
        _error = 'O Jellyfin não informou o identificador deste episódio.';
      });
      return;
    }

    final base = widget.serverUrl.replaceFirst(RegExp(r'/+$'), '');
    final uri = Uri.parse('$base/Videos/$itemId/stream').replace(
      queryParameters: {'Static': 'true'},
    );
    final controller = VideoPlayerController.networkUrl(
      uri,
      httpHeaders: {
        'Authorization': 'MediaBrowser Token=\"${widget.accessToken}\", Client=\"Aurora Nime\", Device=\"Android\", DeviceId=\"aurora-nime-android\", Version=\"1.0.0\"',
        'Accept': '*/*',
      },
    );
    _controller = controller;

    try {
      await controller.initialize().timeout(const Duration(seconds: 45));
      if (!mounted) return;
      await controller.play();
      setState(() {
        _loading = false;
        _error = null;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _loading = false;
        _error = 'Não foi possível iniciar o vídeo. Verifique se o formato é compatível e se o servidor está acessível. ($e)';
      });
    }
  }

  Future<void> _togglePlayback() async {
    final controller = _controller;
    if (controller == null || !controller.value.isInitialized) return;
    if (controller.value.isPlaying) {
      await controller.pause();
    } else {
      await controller.play();
    }
    if (mounted) setState(() => _showControls = true);
  }

  Future<void> _seekBy(int seconds) async {
    final controller = _controller;
    if (controller == null || !controller.value.isInitialized) return;
    final current = controller.value.position;
    final duration = controller.value.duration;
    var target = current + Duration(seconds: seconds);
    if (target < Duration.zero) target = Duration.zero;
    if (target > duration) target = duration;
    await controller.seekTo(target);
    if (mounted) setState(() => _showControls = true);
  }

  KeyEventResult _handleKey(FocusNode node, KeyEvent event) {
    if (event is! KeyDownEvent) return KeyEventResult.ignored;
    switch (event.logicalKey) {
      case LogicalKeyboardKey.select:
      case LogicalKeyboardKey.enter:
      case LogicalKeyboardKey.space:
        _togglePlayback();
        return KeyEventResult.handled;
      case LogicalKeyboardKey.arrowLeft:
        _seekBy(-10);
        return KeyEventResult.handled;
      case LogicalKeyboardKey.arrowRight:
        _seekBy(10);
        return KeyEventResult.handled;
      case LogicalKeyboardKey.arrowUp:
      case LogicalKeyboardKey.arrowDown:
        setState(() => _showControls = true);
        return KeyEventResult.handled;
      case LogicalKeyboardKey.escape:
      case LogicalKeyboardKey.goBack:
        Navigator.of(context).maybePop();
        return KeyEventResult.handled;
    }
    return KeyEventResult.ignored;
  }

  String _format(Duration value) {
    String two(int n) => n.toString().padLeft(2, '0');
    final hours = value.inHours;
    final minutes = value.inMinutes.remainder(60);
    final seconds = value.inSeconds.remainder(60);
    return hours > 0 ? '$hours:${two(minutes)}:${two(seconds)}' : '${two(minutes)}:${two(seconds)}';
  }

  @override
  void dispose() {
    _controller?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final controller = _controller;
    return Scaffold(
      backgroundColor: Colors.black,
      body: SafeArea(
        child: Focus(
          autofocus: true,
          onKeyEvent: _handleKey,
          child: GestureDetector(
            behavior: HitTestBehavior.opaque,
            onTap: () => setState(() => _showControls = !_showControls),
            child: Stack(
              alignment: Alignment.center,
              children: [
                if (controller != null && controller.value.isInitialized)
                  Center(
                    child: AspectRatio(
                      aspectRatio: controller.value.aspectRatio > 0 ? controller.value.aspectRatio : 16 / 9,
                      child: VideoPlayer(controller),
                    ),
                  ),
                if (_loading)
                  const Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [CircularProgressIndicator(color: Color(0xFFB77AFF)), SizedBox(height: 16), Text('Preparando reprodução...')],
                  ),
                if (_error != null)
                  Padding(
                    padding: const EdgeInsets.all(28),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Icon(Icons.error_outline, color: Colors.redAccent, size: 48),
                        const SizedBox(height: 14),
                        Text(_error!, textAlign: TextAlign.center),
                        const SizedBox(height: 18),
                        FilledButton.icon(onPressed: () { setState(() { _loading = true; _error = null; }); _initializePlayer(); }, icon: const Icon(Icons.refresh), label: const Text('Tentar novamente')),
                      ],
                    ),
                  ),
                if (!_loading && _error == null && controller != null && controller.value.isInitialized && _showControls)
                  Positioned.fill(
                    child: Container(
                      decoration: const BoxDecoration(
                        gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Color(0xB8000000), Colors.transparent, Color(0xC9000000)], stops: [0, .48, 1]),
                      ),
                      child: Column(
                        children: [
                          Row(children: [IconButton(autofocus: true, onPressed: () => Navigator.of(context).pop(), icon: const Icon(Icons.arrow_back)), Expanded(child: Text(_title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold))), const SizedBox(width: 12)]),
                          const Spacer(),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              IconButton(onPressed: () => _seekBy(-10), iconSize: 38, icon: const Icon(Icons.replay_10)),
                              const SizedBox(width: 26),
                              IconButton(autofocus: true, onPressed: _togglePlayback, iconSize: 58, icon: Icon(controller.value.isPlaying ? Icons.pause_circle_filled : Icons.play_circle_fill)),
                              const SizedBox(width: 26),
                              IconButton(onPressed: () => _seekBy(10), iconSize: 38, icon: const Icon(Icons.forward_10)),
                            ],
                          ),
                          const Spacer(),
                          Padding(
                            padding: const EdgeInsets.fromLTRB(22, 0, 22, 18),
                            child: Column(children: [
                              VideoProgressIndicator(controller, allowScrubbing: true, padding: const EdgeInsets.symmetric(vertical: 10), colors: const VideoProgressColors(playedColor: Color(0xFFB77AFF), bufferedColor: Colors.white38, backgroundColor: Colors.white24)),
                              Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Text(_format(controller.value.position)), Text(_format(controller.value.duration))]),
                            ]),
                          ),
                        ],
                      ),
                    ),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
