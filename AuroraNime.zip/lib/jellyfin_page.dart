import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'jellyfin_player_page.dart';

const _jfPurple = Color(0xFF9B59E8);
const _jfPanel = Color(0xFF1B1728);

class JellyfinPage extends StatefulWidget {
  const JellyfinPage({super.key});

  @override
  State<JellyfinPage> createState() => _JellyfinPageState();
}

class _JellyfinPageState extends State<JellyfinPage> {
  final _server = TextEditingController(text: 'http://192.168.0.4:8096');
  final _username = TextEditingController();
  final _password = TextEditingController();
  bool _busy = false;
  bool _connected = false;
  String? _error;
  String? _token;
  String? _userId;
  List<Map<String, dynamic>> _libraries = [];
  List<Map<String, dynamic>> _episodes = [];

  String get _baseUrl => _server.text.trim().replaceFirst(RegExp(r'/+$'), '');

  Map<String, String> get _headers => {
    'Accept': 'application/json',
    'Content-Type': 'application/json',
    'Authorization': 'MediaBrowser Client="Aurora Nime", Device="Android", DeviceId="aurora-nime-android", Version="1.0.0"${_token != null ? ', Token=\"$_token\"' : ''}',
  };

  Future<void> _connect() async {
    FocusScope.of(context).unfocus();
    if (_username.text.trim().isEmpty || _password.text.isEmpty) {
      setState(() => _error = 'Informe o usuário e a senha do Jellyfin.');
      return;
    }
    setState(() { _busy = true; _error = null; _connected = false; });
    try {
      final uri = Uri.parse('$_baseUrl/Users/AuthenticateByName');
      final response = await http.post(uri,
        headers: _headers,
        body: jsonEncode({'Username': _username.text.trim(), 'Pw': _password.text}),
      ).timeout(const Duration(seconds: 15));
      if (response.statusCode != 200) {
        throw Exception(response.statusCode == 401
          ? 'Usuário ou senha não reconhecidos pelo Jellyfin.'
          : 'O servidor respondeu HTTP ${response.statusCode}.');
      }
      final data = jsonDecode(response.body) as Map<String, dynamic>;
      final token = data['AccessToken']?.toString();
      final user = data['User'] as Map<String, dynamic>?;
      final userId = user?['Id']?.toString();
      if (token == null || userId == null) throw Exception('O Jellyfin não retornou os dados de autenticação.');
      _token = token;
      _userId = userId;
      await _loadLibraries();
      if (!mounted) return;
      setState(() { _connected = true; _busy = false; _password.clear(); });
    } catch (e) {
      if (!mounted) return;
      setState(() { _busy = false; _error = e.toString().replaceFirst('Exception: ', ''); });
    }
  }

  Future<void> _loadLibraries() async {
    final uri = Uri.parse('$_baseUrl/Users/$_userId/Views');
    final response = await http.get(uri, headers: _headers).timeout(const Duration(seconds: 15));
    if (response.statusCode != 200) throw Exception('Não foi possível carregar as bibliotecas (HTTP ${response.statusCode}).');
    final data = jsonDecode(response.body) as Map<String, dynamic>;
    _libraries = ((data['Items'] as List?) ?? []).whereType<Map>().map((e) => Map<String, dynamic>.from(e)).toList();
    if (_libraries.isNotEmpty) await _loadEpisodes();
  }

  Future<void> _loadEpisodes([String? parentId]) async {
    setState(() { _busy = true; _error = null; });
    try {
      final query = <String, String>{
        'UserId': _userId!,
        'IncludeItemTypes': 'Episode',
        'Recursive': 'true',
        'Fields': 'Overview,ParentId,SeriesName,IndexNumber,ParentIndexNumber,RunTimeTicks',
        'SortBy': 'SortName',
        'SortOrder': 'Ascending',
      };
      if (parentId != null) query['ParentId'] = parentId;
      final uri = Uri.parse('$_baseUrl/Items').replace(queryParameters: query);
      final response = await http.get(uri, headers: _headers).timeout(const Duration(seconds: 20));
      if (response.statusCode != 200) throw Exception('Falha ao buscar episódios (HTTP ${response.statusCode}).');
      final data = jsonDecode(response.body) as Map<String, dynamic>;
      _episodes = ((data['Items'] as List?) ?? []).whereType<Map>().map((e) => Map<String, dynamic>.from(e)).toList();
      if (!mounted) return;
      setState(() => _busy = false);
    } catch (e) {
      if (!mounted) return;
      setState(() { _busy = false; _error = e.toString().replaceFirst('Exception: ', ''); });
    }
  }

  void _disconnect() => setState(() {
    _token = null; _userId = null; _connected = false; _libraries = []; _episodes = []; _error = null;
  });

  @override
  void dispose() {
    _server.dispose(); _username.dispose(); _password.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Minha mídia'),
        actions: [if (_connected) IconButton(tooltip: 'Desconectar', onPressed: _disconnect, icon: const Icon(Icons.logout))],
      ),
      body: SafeArea(child: Center(child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 760),
        child: ListView(padding: const EdgeInsets.all(20), children: [
          const Text('JELLYFIN', style: TextStyle(color: Color(0xFFD2A0FF), fontSize: 12, fontWeight: FontWeight.bold, letterSpacing: 2)),
          const SizedBox(height: 6),
          Text(_connected ? 'Conectado ao seu servidor' : 'Conecte seu servidor de mídia', style: const TextStyle(fontSize: 23, fontWeight: FontWeight.w800)),
          const SizedBox(height: 18),
          if (!_connected) ...[
            TextField(controller: _server, keyboardType: TextInputType.url, decoration: const InputDecoration(labelText: 'Endereço do servidor', hintText: 'http://192.168.0.4:8096', filled: true, fillColor: _jfPanel, border: OutlineInputBorder())),
            const SizedBox(height: 12),
            TextField(controller: _username, textInputAction: TextInputAction.next, decoration: const InputDecoration(labelText: 'Usuário Jellyfin', filled: true, fillColor: _jfPanel, border: OutlineInputBorder())),
            const SizedBox(height: 12),
            TextField(controller: _password, obscureText: true, onSubmitted: (_) => _connect(), decoration: const InputDecoration(labelText: 'Senha Jellyfin', filled: true, fillColor: _jfPanel, border: OutlineInputBorder())),
            const SizedBox(height: 14),
            FilledButton.icon(onPressed: _busy ? null : _connect, icon: const Icon(Icons.link), label: const Text('Conectar ao Jellyfin')),
            const SizedBox(height: 8),
            const Text('A senha é usada somente para autenticar nesta sessão e não é salva pelo Aurora Nime.', style: TextStyle(color: Colors.white60, fontSize: 12)),
          ] else ...[
            Container(padding: const EdgeInsets.all(14), decoration: BoxDecoration(color: _jfPanel, borderRadius: BorderRadius.circular(14)), child: Row(children: [const Icon(Icons.check_circle, color: Colors.greenAccent), const SizedBox(width: 10), Expanded(child: Text(_baseUrl, style: const TextStyle(fontWeight: FontWeight.w600))), IconButton(onPressed: _loadEpisodes, icon: const Icon(Icons.refresh), tooltip: 'Atualizar episódios')])) ,
            const SizedBox(height: 18),
            const Text('BIBLIOTECAS', style: TextStyle(color: Color(0xFFD2A0FF), fontWeight: FontWeight.bold, letterSpacing: 1.2)),
            const SizedBox(height: 8),
            if (_libraries.isEmpty) const Text('Nenhuma biblioteca foi retornada pelo servidor.'),
            for (final library in _libraries) ListTile(contentPadding: EdgeInsets.zero, leading: const Icon(Icons.video_library_outlined, color: _jfPurple), title: Text(library['Name']?.toString() ?? 'Biblioteca'), subtitle: Text(library['CollectionType']?.toString() ?? 'Mídia'), onTap: () => _loadEpisodes(library['Id']?.toString())),
            const SizedBox(height: 12),
            Text('EPISÓDIOS (${_episodes.length})', style: const TextStyle(color: Color(0xFFD2A0FF), fontWeight: FontWeight.bold, letterSpacing: 1.2)),
            const SizedBox(height: 8),
            if (_episodes.isEmpty && !_busy) const Text('Nenhum episódio foi retornado nesta biblioteca.'),
            for (final episode in _episodes) ListTile(
              contentPadding: EdgeInsets.zero,
              leading: const Icon(Icons.play_circle_outline, color: _jfPurple, size: 30),
              title: Text(episode['Name']?.toString() ?? 'Episódio'),
              subtitle: Text('${episode['SeriesName'] ?? 'Série'}${episode['ParentIndexNumber'] != null ? ' • T${episode['ParentIndexNumber']}' : ''}${episode['IndexNumber'] != null ? ' • Ep. ${episode['IndexNumber']}' : ''}'),
              onTap: () {
                Navigator.of(context).push(MaterialPageRoute(
                  builder: (_) => JellyfinPlayerPage(
                    serverUrl: _baseUrl,
                    accessToken: _token!,
                    episode: episode,
                  ),
                ));
              },
            ),
          ],
          if (_busy) const Padding(padding: EdgeInsets.all(20), child: Center(child: CircularProgressIndicator())),
          if (_error != null) Padding(padding: const EdgeInsets.only(top: 14), child: Text(_error!, style: const TextStyle(color: Colors.redAccent))),
        ]),
      ))),
    );
  }
}
