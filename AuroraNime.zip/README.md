# Aurora Nime — base multiplataforma Flutter

Base inicial para **Android (celular/tablet), Android TV, TV Stick/TV Box compatíveis com Android TV e iOS (iPhone/iPad)**.

## O que já existe
- Interface responsiva para telas pequenas e grandes.
- Capa oficial enviada pelo usuário incluída como imagem do projeto e ícone Android.
- Navegação por toque e componentes com foco para teclado/controle remoto.
- Catálogo de demonstração, busca, filtros e favoritos em memória.
- Tema visual roxo do Aurora Nime.

## Requisitos
- Flutter SDK estável (3.22 ou superior recomendado)
- Android Studio + Android SDK para Android
- macOS + Xcode para compilar, assinar e publicar no iOS

## Executar
```bash
flutter pub get
flutter run
```

## Gerar Android APK
```bash
flutter build apk --release
```
Saída: `build/app/outputs/flutter-apk/app-release.apk`

## Gerar iOS
Em um Mac com Xcode configurado:
```bash
flutter build ios --release
```
A publicação exige assinatura Apple e revisão da App Store.

## Android TV / TV Stick / TV Box
A interface é responsiva e os cartões/botões usam controles Flutter focáveis. Para distribuição ampla em TVs, ainda é necessário testar em aparelhos reais, ajustar navegação D-pad/foco, metadados Leanback, banner e requisitos de cada fabricante/loja. Nem todo TV Box genérico possui a mesma compatibilidade.

## Limitações desta versão
- Conteúdo e emojis são demonstrativos, não capas oficiais.
- Não há streaming, episódios, atualização automática ou API de catálogo.
- Favoritos ficam apenas na memória durante a sessão; persistência e sincronização serão adicionadas depois.
- Integrações futuras devem usar catálogos e serviços com direitos/licenças apropriados.
