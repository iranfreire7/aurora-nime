# Aurora Nime

Aplicativo Flutter para descoberta e organização de animes, com interface responsiva para celular e telas maiores.

## Jellyfin

A primeira etapa de integração está disponível em **Minha mídia**, pelo ícone de biblioteca na tela inicial. Ela permite informar o endereço do servidor, autenticar com a conta Jellyfin e consultar bibliotecas e episódios. O endereço inicial é `http://192.168.0.4:8096`, correspondente ao servidor configurado no S20 FE durante os testes; pode ser alterado na tela.

A senha é usada apenas para autenticação e não é salva. O token fica em memória durante a sessão. A reprodução de vídeos dentro do Aurora Nime ainda não está incluída nesta etapa.

## Build

O workflow `.github/workflows/android-apk.yml` gera o APK pelo GitHub Actions. Consulte `TESTE.md` para o roteiro da etapa atual.

## Reprodução Jellyfin (etapa 2)

A tela **Minha mídia** autentica no servidor Jellyfin, consulta bibliotecas/episódios e agora abre o episódio selecionado em um player integrado com `video_player` (Android/TV). O player envia o token de sessão ao endpoint de vídeo do Jellyfin e inclui controles de reprodução, avanço/retrocesso de 10 segundos e navegação por controle remoto (setas, OK/Enter e voltar).

Para testar: conecte o Aurora Nime ao mesmo servidor Jellyfin já configurado, abra **Minha mídia**, conecte com a conta Jellyfin e selecione um episódio listado. A reprodução depende dos formatos/contêineres suportados pelo ExoPlayer do Android e das permissões do usuário no Jellyfin.

A compilação final deve ser validada pelo workflow **Gerar APK Aurora Nime** no GitHub Actions.
