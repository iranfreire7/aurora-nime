# Aurora Nime — revisão segura do projeto Flutter

Esta revisão parte da versão `correcao_completa` e procura preservar a interface, os assets e os recursos já existentes enquanto melhora a identificação do anime e a recuperação de episódios.

## Recursos presentes
- Interface responsiva com identidade visual do Aurora Nime.
- Pesquisa online pela API Tenrai.
- Capas, detalhes, filtros e favoritos em memória.
- Listagem de episódios com paginação Tenrai.
- Consulta complementar Jikan, deduplicação e ordenação numérica.
- Ação para tentar novamente a consulta secundária quando ela não termina por falha ou limite de requisições.

## Requisitos
- Flutter SDK estável (3.22 ou superior recomendado).
- Android Studio e Android SDK para compilar Android.
- macOS e Xcode para compilar iOS.

## Executar
```bash
flutter pub get
flutter run
```

## Gerar APK Android
```bash
flutter build apk --release
```
Saída: `build/app/outputs/flutter-apk/app-release.apk`.

## Importante
- Este ZIP contém código-fonte, não um APK instalado ou validado.
- A revisão não implementa tradução automática de títulos e sinopses; o idioma depende das fontes.
- A recuperação complementar depende da disponibilidade e dos limites públicos da Jikan.
- Antes de distribuir, compile pelo GitHub Actions e teste pesquisa, detalhes, Demon Slayer e Overgeared em aparelho Android.
